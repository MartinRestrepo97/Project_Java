package com.productmanagement;

import com.productmanagement.controller.ProductController;
import com.productmanagement.model.Product;

import javax.swing.*;
import java.awt.*;
import java.io.File;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.List;

public class ProductManagementApp extends JFrame {
    private final ProductController productController;
    private JList<Product> productList;
    private DefaultListModel<Product> listModel;

    public ProductManagementApp() {
        productController = new ProductController();
        initUI();
        loadProducts();
    }

    private void initUI() {
        setTitle("Product Management");
        setSize(800, 600);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        listModel = new DefaultListModel<>();
        productList = new JList<>(listModel);
        productList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        add(new JScrollPane(productList), BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel();
        buttonPanel.add(createButton("Create", e -> createProduct()));
        buttonPanel.add(createButton("Edit", e -> editProduct()));
        buttonPanel.add(createButton("Delete", e -> deleteProduct()));
        add(buttonPanel, BorderLayout.SOUTH);
    }

    private JButton createButton(String text, java.awt.event.ActionListener listener) {
        JButton button = new JButton(text);
        button.addActionListener(listener);
        return button;
    }

    private void loadProducts() {
        try {
            List<Product> products = productController.getAllProducts();
            listModel.clear();
            for (Product product : products) {
                listModel.addElement(product);
            }
        } catch (SQLException e) {
            showErrorMessage("Error loading products: " + e.getMessage());
        }
    }

    private void createProduct() {
        Product product = new Product();
        if (showProductDialog(product, "Create Product")) {
            try {
                productController.createProduct(product);
                loadProducts();
            } catch (SQLException e) {
                showErrorMessage("Error creating product: " + e.getMessage());
            }
        }
    }

    private void editProduct() {
        Product selectedProduct = productList.getSelectedValue();
        if (selectedProduct == null) {
            showErrorMessage("Please select a product to edit.");
            return;
        }

        if (showProductDialog(selectedProduct, "Edit Product")) {
            try {
                productController.updateProduct(selectedProduct);
                loadProducts();
            } catch (SQLException e) {
                showErrorMessage("Error updating product: " + e.getMessage());
            }
        }
    }

    private void deleteProduct() {
        Product selectedProduct = productList.getSelectedValue();
        if (selectedProduct == null) {
            showErrorMessage("Please select a product to delete.");
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(this,
                "Are you sure you want to delete this product?",
                "Confirm Deletion",
                JOptionPane.YES_NO_OPTION);

        if (confirm == JOptionPane.YES_OPTION) {
            try {
                productController.deleteProduct(selectedProduct.getId());
                loadProducts();
            } catch (SQLException e) {
                showErrorMessage("Error deleting product: " + e.getMessage());
            }
        }
    }

    private boolean showProductDialog(Product product, String title) {
        JTextField nameField = new JTextField(product.getName());
        JTextField descriptionField = new JTextField(product.getDescription());
        JTextField farmerField = new JTextField(product.getFarmer());
        JTextField image1Field = new JTextField(product.getImage1());
        JTextField image2Field = new JTextField(product.getImage2());
        JTextField image3Field = new JTextField(product.getImage3());

        JPanel panel = new JPanel(new GridLayout(0, 1));
        panel.add(new JLabel("Name:"));
        panel.add(nameField);
        panel.add(new JLabel("Description:"));
        panel.add(descriptionField);
        panel.add(new JLabel("Farmer:"));
        panel.add(farmerField);
        panel.add(new JLabel("Image 1:"));
        panel.add(image1Field);
        panel.add(createImageButton(image1Field));
        panel.add(new JLabel("Image 2 (optional):"));
        panel.add(image2Field);
        panel.add(createImageButton(image2Field));
        panel.add(new JLabel("Image 3 (optional):"));
        panel.add(image3Field);
        panel.add(createImageButton(image3Field));

        int result = JOptionPane.showConfirmDialog(this, panel, title, JOptionPane.OK_CANCEL_OPTION);
        if (result == JOptionPane.OK_OPTION) {
            product.setName(nameField.getText());
            product.setDescription(descriptionField.getText());
            product.setFarmer(farmerField.getText());
            product.setImage1(image1Field.getText());
            product.setImage2(image2Field.getText());
            product.setImage3(image3Field.getText());
            product.setUpdatedAt(LocalDateTime.now());
            return true;
        }
        return false;
    }

    private JButton createImageButton(JTextField imageField) {
        JButton button = new JButton("Select Image");
        button.addActionListener(e -> {
            JFileChooser fileChooser = new JFileChooser();
            int result = fileChooser.showOpenDialog(this);
            if (result == JFileChooser.APPROVE_OPTION) {
                File selectedFile = fileChooser.getSelectedFile();
                imageField.setText(selectedFile.getAbsolutePath());
            }
        });
        return button;
    }

    private void showErrorMessage(String message) {
        JOptionPane.showMessageDialog(this, message, "Error", JOptionPane.ERROR_MESSAGE);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            ProductManagementApp app = new ProductManagementApp();
            app.setVisible(true);
        });
    }
}
